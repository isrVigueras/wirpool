package com.tikal.fiscal.model;

import java.util.List;

public class Usuario {
	private String nombre;
	private String password;
	private String email;
	private List<Long> clientes;
}
