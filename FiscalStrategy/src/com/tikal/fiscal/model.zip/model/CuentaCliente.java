package com.tikal.fiscal.model;

public class CuentaCliente extends Cuenta{
	private Long id_cliente;
	
}
