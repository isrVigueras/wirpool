package com.tikal.fiscal.model;

import java.util.Date;

public class PagoRecibido {
	private Long id;
	private String cuenta;
	private String banco;
	private Date fecha;
	private Long id_brocker;
	private Long id_cliente;
	private float monto;
}
