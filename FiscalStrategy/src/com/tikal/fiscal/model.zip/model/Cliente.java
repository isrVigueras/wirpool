package com.tikal.fiscal.model;

public class Cliente {
	private Long id;
	private String nickname;
	private String tipo;
}
