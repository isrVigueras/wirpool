package com.tikal.fiscal.model;

public class Cuenta {
	private Long id;
	private String banco;
	private String cuenta;
	private String clabe;
	private String nombre;
}
